#ifndef _TYPES_CACHE_H
#define _TYPES_CACHE_H

struct applet http_cache_applet;

#endif /*_TYPES_CACHE_H */


